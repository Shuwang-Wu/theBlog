/**
 * @Description  : 组件入口文件
 * @Author       : YH000052
 * @LastEditors  : YH000052
 * @Date         : 2020-07-28 15:27:27
 * @LastEditTime : 2020-07-29 11:57:20
 * @FilePath     : \bid\src\components\index.js
 */

export { default as Navbar } from "./navbar"
