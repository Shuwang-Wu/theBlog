export default {
  navigationBarTitleText: '个人中心'
}
