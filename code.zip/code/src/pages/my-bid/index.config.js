export default {
  navigationBarTitleText: '我的竞拍'
}
