export default {
  navigationBarTitleText: '竞拍中心'
}
