module.exports = {
  'extends': ['taro/react']
}
